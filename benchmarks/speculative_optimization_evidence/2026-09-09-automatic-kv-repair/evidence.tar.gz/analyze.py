import json,pathlib,xml.etree.ElementTree as ET
root=pathlib.Path(__file__).resolve().parent
final=root/'qualified'
plan=json.loads((final/'plan.json').read_text())
status=json.loads((final/'status.json').read_text())
assert len(status)==6 and all(s['exit_code']==0 for s in status)
results=[]
controls=[]
for name,_ in plan['checks']:
 d=json.loads((final/(name+'.json')).read_text())
 assert d['revision']==plan['revision'] and d['source_sha256']==plan['source_hashes']
 assert len(d['sweep_cells'])==80 and d['cycles']
 assert all(not c['compile_delta'] for c in d['cycles'])
 if d['args']['retained']:assert all(c['compiler_unchanged'] for c in d['cycles'])
 reference_name = ('eager-invariant-off' if d['args']['numerical_mode']=='invariant' else 'eager-fast-off' if d['args']['mode']=='eager' else 'graph-fast-off')
 reference=json.loads((root/(reference_name+'-reference.json')).read_text())
 assert reference['model_files']==d['model_files'] and reference['draft_model_files']==d['draft_model_files']
 control={(x['length'],x['batch']):x['tokens'] for x in reference['results']}
 assert len(d['results'])==4
 for row in d['results']:
  assert row['tokens']==control[(row['length'],row['batch'])]
  assert row['cache_repeat'] and row['stream_parity']
 controls.append({'run':name,'reference':reference_name,'reference_revision':reference['revision'],'matched_workloads':4})
 a=d['audit'];assert a['modeled_runtime_headroom_bytes']>=0
 assert a['persistent_workspace_reservation_bytes']==64*1024**2
 assert a['runtime_reservation_bytes']==a['profiled_graph_ownership_bytes']+a['warmup_transient_bytes']+a['workspace_plan']['reservation_bytes']+a['persistent_workspace_reservation_bytes']
 assert a['modeled_runtime_headroom_bytes']==a['post_init_budget_headroom_bytes']-a['warmup_transient_bytes']-a['workspace_plan']['reservation_bytes']
 results.append({'name':name,'cycles':len(d['cycles']),'sweep_cells':len(d['sweep_cells']),'selected_blocks':a['selected_num_blocks'],'runtime_headroom_bytes':a['modeled_runtime_headroom_bytes'],'persistent_reservation_bytes':a['persistent_workspace_reservation_bytes'],'strict_compiler_guards':d['args']['retained']})
suites=ET.parse(final/'pytest.xml').getroot();counts={k:sum(int(s.get(k,0)) for s in suites.iter('testsuite')) for k in ('tests','failures','errors','skipped')};assert counts['failures']==counts['errors']==0
summary={'revision':plan['revision'],'checks':results,'pytest':counts,'ordinary_controls':controls,'initial_attempt':{'revision':'6ec2e3d40b9a3f8fff9aa9d5f64f41272e27e7eb','passed':False,'reason':'Moving allocations before sizing alone left a 10,583,447-byte headroom shortfall; superseded by explicit reservation.'},'intermediate_attempt':{'revision':'d48141d','graph_b4_b5_and_eager_passed':True,'invariant_passed':False,'reason':'Unrounded explicit reserve left a 4,931,500-byte invariant-mode headroom shortfall; superseded by whole-joint-block reservation.'},'passed':True,'limits':'Qwen3-4B target / Qwen3-0.6B draft, A100 40GB, TP1, BF16, utilization 0.5, K4. Lifecycle verification, not a new five-pair performance qualification. Conservative permanent-buffer reserve plus unchanged legacy phase reserve; automatic KV capacity may be lower.'}
(root/'analysis.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
