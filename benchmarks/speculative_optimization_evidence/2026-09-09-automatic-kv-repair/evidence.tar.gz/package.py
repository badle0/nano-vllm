import gzip,hashlib,io,json,pathlib,tarfile
root=pathlib.Path(__file__).resolve().parent
repo=pathlib.Path('/workspace/nano-vllm')
out=repo/'benchmarks/speculative_optimization_evidence/2026-09-09-automatic-kv-repair'
out.mkdir(parents=True,exist_ok=True)
paths=sorted([p for parent in (root,root/'final',root/'qualified') for p in parent.iterdir() if p.is_file() and p.name!='SHA256SUMS'])
manifest={str(p.relative_to(root)):{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in paths}
(root/'SHA256SUMS').write_text(''.join(f"{v['sha256']}  {k}\n" for k,v in manifest.items()))
paths.append(root/'SHA256SUMS')
archive=out/'evidence.tar.gz'
with archive.open('wb') as dest:
 with gzip.GzipFile(fileobj=dest,mode='wb',mtime=0,filename='') as gz:
  with tarfile.open(fileobj=gz,mode='w') as t:
   for p in paths:
    b=p.read_bytes();i=tarfile.TarInfo(str(p.relative_to(root)));i.size=len(b);i.mode=0o644;t.addfile(i,io.BytesIO(b))
with tarfile.open(archive) as t:
 for name,info in manifest.items():
  b=t.extractfile(name).read();assert len(b)==info['bytes'] and hashlib.sha256(b).hexdigest()==info['sha256']
summary=json.loads((root/'analysis.json').read_text())
(out/'manifest.json').write_text(json.dumps({'producer_commit':summary['revision'],'archive':{'name':archive.name,'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()},'files':manifest},indent=2)+'\n')
(out/'README.md').write_text('''# Automatic-KV accounting repair evidence

See the [repair qualification](../../../docs/AUTOMATIC_KV_REPAIR.md).
`evidence.tar.gz` retains the original probes, two unsuccessful repair attempts,
the final passing lifecycle sweeps and pytest results, exact source patch,
source hashes, and execution/analysis scripts. `qualified/` contains the final
passing runs; `final/` is the preserved intermediate attempt and is superseded.
`analysis.json` identifies each revision and outcome.

`manifest.json` records the archive checksum and every payload file checksum;
the archive also includes SHA256SUMS. Compiler caches and model weights are
excluded. Scripts retain the producer instance's absolute model/environment
paths and require adapting those paths when reproducing elsewhere.

The final tests cover the recorded A100/Qwen3 single-GPU configuration.
This is lifecycle and memory-accounting verification, not a new five-pair
performance certificate.
''')
(repo/'docs/AUTOMATIC_KV_REPAIR.md').write_bytes((root/'REPORT.md').read_bytes())
print('Packaged',len(paths),'files;',archive.stat().st_size,'bytes')
