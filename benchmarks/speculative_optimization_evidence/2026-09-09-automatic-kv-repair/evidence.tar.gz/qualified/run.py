import datetime,json,os,pathlib,subprocess,hashlib
root=pathlib.Path(__file__).resolve().parent
repo=pathlib.Path('/workspace/nano-vllm'); python='/workspace/venvs/nano-vllm/bin/python'
revision=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
env=os.environ.copy();env.update(PYTHONDONTWRITEBYTECODE='1',PYTHONPATH=str(repo),HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',CUDA_VISIBLE_DEVICES='0',NANOVLLM_TEST_TOKENIZER_PATH='/workspace/models/Qwen3-0.6B',TORCH_LOGS='recompiles,graph_breaks')
for k in ['TORCHINDUCTOR_FX_GRAPH_REMOTE_CACHE','TORCHINDUCTOR_AUTOGRAD_CACHE','TORCHINDUCTOR_AUTOGRAD_REMOTE_CACHE','TORCHINDUCTOR_AUTOTUNE_REMOTE_CACHE','TORCHINDUCTOR_BUNDLED_AUTOTUNE_REMOTE_CACHE','TORCH_DYNAMO_AUTOMATIC_DYNAMIC_LOCAL_PGO','TORCH_DYNAMO_AUTOMATIC_DYNAMIC_REMOTE_PGO']:env[k]='0'
for k in ['TORCH_COMPILE_DISABLE','TORCHDYNAMO_DISABLE','TORCHDYNAMO_SUPPRESS_ERRORS']:env.pop(k,None)
checks=[('graph-auto-b5',['--mode','graph','--max-batch','5','--auto-kv','--retained','--expected-commit',revision]),('graph-auto-b4',['--mode','graph','--max-batch','4','--auto-kv','--retained','--expected-commit',revision]),('eager-auto-b5',['--mode','eager','--max-batch','5','--auto-kv']),('invariant-auto-b4',['--mode','eager','--numerical-mode','invariant','--max-batch','4','--auto-kv']),('graph-fixed-b5',['--mode','graph','--max-batch','5','--retained','--expected-commit',revision])]
(root/'plan.json').write_text(json.dumps({'revision':revision,'source_hashes':{str(p.relative_to(repo)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((repo/'nanovllm').rglob('*.py'))},'checks':checks,'models':['Qwen3-4B','Qwen3-0.6B'],'memory_utilization':.5,'purpose':'Automatic KV repair: formerly failing B4/B5 graph cases, eager/invariant and fixed-KV regression, then full pytest.'},indent=2)+'\n')
checks.sort(key=lambda check: check[0] != 'invariant-auto-b4')
status=[]
for name,args in checks:
 print('START',name,datetime.datetime.now(datetime.timezone.utc).isoformat(),flush=True)
 e=env.copy();e.update(TORCHINDUCTOR_CACHE_DIR=str(root/(name+'-inductor-cache')),TRITON_CACHE_DIR=str(root/(name+'-triton-cache')))
 cmd=[python,'tests/run_speculative_v5_gpu.py','--model','/workspace/models/Qwen3-4B','--draft-model','/workspace/models/Qwen3-0.6B','--enabled','--sweep',*args,'--output',str(root/(name+'.json'))]
 with (root/(name+'.log')).open('x') as f:rc=subprocess.run(cmd,cwd=repo,env=e,stdout=f,stderr=subprocess.STDOUT).returncode
 status.append({'name':name,'exit_code':rc,'command':cmd});(root/'status.json').write_text(json.dumps(status,indent=2)+'\n');print('FINISH',name,rc,flush=True)
 if rc:raise SystemExit(rc)
e=env.copy();e.update(TORCHINDUCTOR_CACHE_DIR=str(root/'pytest-inductor-cache'),TRITON_CACHE_DIR=str(root/'pytest-triton-cache'))
print('START full pytest',flush=True)
with (root/'pytest.log').open('x') as f:rc=subprocess.run([python,'-m','pytest','-q','--junitxml='+str(root/'pytest.xml')],cwd=repo,env=e,stdout=f,stderr=subprocess.STDOUT).returncode
status.append({'name':'full-pytest','exit_code':rc});(root/'status.json').write_text(json.dumps(status,indent=2)+'\n');print('FINISH full pytest',rc,flush=True)
raise SystemExit(rc)
