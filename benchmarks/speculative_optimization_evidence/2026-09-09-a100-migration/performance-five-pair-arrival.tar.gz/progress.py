import json
from pathlib import Path
p=Path(__file__).resolve().parent
s=json.loads((p/'status.json').read_text()) if (p/'status.json').exists() else {}
print('completed:',len(s.get('runs',[])),'accepted:',sum(r.get('accepted',0) for r in s.get('runs',[])),'samples:',sum(r.get('samples',0) for r in s.get('runs',[])))
lines=(p/'runner.log').read_text().splitlines()
print('\n'.join(lines[-2:]))
starts=[l for l in lines if l.startswith('START ')]
if starts:
 log=p/(starts[-1].split()[1]+'.log')
 if log.exists():print('\n'.join(log.read_text().splitlines()[-2:]))
if (p/'pytest.log').exists():print('pytest:',(p/'pytest.log').read_text()[-900:])
