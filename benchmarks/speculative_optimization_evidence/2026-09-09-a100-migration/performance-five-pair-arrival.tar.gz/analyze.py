"""Validate fresh primary pairs and summarize exact process-pair bootstrap ratios."""
import collections, hashlib, itertools, json, math, pathlib, statistics, subprocess
import xml.etree.ElementTree as ET
root=pathlib.Path(__file__).resolve().parent
repo=pathlib.Path('/workspace/nano-vllm')
plan=json.loads((root/'plan.json').read_text())
status=json.loads((root/'status.json').read_text())
expected={(b,c,f,'generate',64,s) for b in (1,4,8) for c in (32,256) for f in ('greedy','plain','topk','topp','combined') for s in (17,23,41)}
def key(r):return tuple(r[k] for k in ('batch','context','family','consumer','completion'))
def fullkey(r):return key(r)+(r['seed'],)
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert digest(repo/'tests/run_speculative_v7_benchmark.py')==plan['harness_sha256']
assert subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip()==plan['revision']
runs={};excluded=[];greedy_mismatches=[];route_failures=[];sequence=[]
for entry in status['runs']:
 pair,side=entry['pair'],entry['side']
 if entry['exit_code']!=0:continue
 p=root/f'pair{pair:02d}-{side}.json';d=json.loads(p.read_text())
 assert d['runtime_revision']==plan['revision'] and d['harness_sha256']==plan['harness_sha256']
 assert d['args']['pair']==pair and bool(d['args']['enabled'])==(side=='on')
 assert d['args']['suite']=='primary' and d['args']['mode']=='graph'
 assert d['args']['model']=='/workspace/models/Qwen3-4B' and d['args']['draft_model']=='/workspace/models/Qwen3-0.6B'
 assert d['warmups_per_cell']==2 and d['seeds']==[17,23,41]
 assert len(d['records'])==90 and {fullkey(r) for r in d['records']}==expected
 assert d['config']['num_kvcache_blocks']==64 and d['config']['max_num_batched_tokens']==4096 and d['config']['max_model_len']==4096
 for name,value in d['source_sha256'].items():assert digest(repo/name)==value
 if runs:
  previous=next(iter(runs.values()))
  assert d['models']==previous['models'] and d['source_sha256']==previous['source_sha256']
 for r in d['records']:
  assert r['pair']==pair and r['seconds']>0 and math.isfinite(r['seconds'])
  assert len(r['outputs'])==r['batch'] and all(len(o['token_ids'])==64 for o in r['outputs'])
  assert r['accepted']==(not r['rejection_reasons'])
  if not r['accepted']:excluded.append({'pair':pair,'side':side,'cell':key(r),'seed':r['seed'],'reasons':r['rejection_reasons']})
  cycles=sum(o['metrics'].get('spec_cycles',0) for o in r['outputs'])
  if (side=='off' or r['batch']==8) and cycles!=0:route_failures.append({'pair':pair,'side':side,'cell':key(r),'seed':r['seed'],'cycles':cycles})
  if side=='on' and r['batch']<=4 and cycles<=0:route_failures.append({'pair':pair,'side':side,'cell':key(r),'seed':r['seed'],'cycles':cycles})
 runs[pair,side]=d;sequence.append(d)
for a,b in zip(sequence,sequence[1:]):assert a['samples_finished_ns']<b['process_started_ns']
for pair in range(6):
 if not all((pair,side) in runs for side in ('off','on')):continue
 a,b=({fullkey(r):r for r in runs[pair,side]['records']} for side in ('off','on'))
 for k in expected:
  if k[2]=='greedy' and [o['token_ids'] for o in a[k]['outputs']] != [o['token_ids'] for o in b[k]['outputs']]:greedy_mismatches.append({'pair':pair,'cell':k[:-1],'seed':k[-1]})
cells=[]
for cell in sorted({k[:-1] for k in expected}):
 ratios=[];selected=[];off=[];on=[];totals=collections.Counter()
 for pair in range(6):
  if not all((pair,s) in runs for s in ('off','on')):continue
  groups=[{r['seed']:r for r in runs[pair,s]['records'] if key(r)==cell} for s in ('off','on')]
  if not all(all(r['accepted'] for r in group.values()) for group in groups):continue
  a,b=groups;ratios.append(statistics.median(a[s]['seconds']/b[s]['seconds'] for s in (17,23,41)));selected.append(pair)
  off.extend(r['seconds'] for r in a.values());on.extend(r['seconds'] for r in b.values())
  for r in b.values():
   for o in r['outputs']:
    for k,v in o['metrics'].items():
     if k.startswith('spec_'):totals[k]+=v
  if len(ratios)==5:break
 interval=None
 if len(ratios)==5:
  bootstrap=sorted(statistics.median(x) for x in itertools.product(ratios,repeat=5))
  interval=[bootstrap[int((len(bootstrap)-1)*p)] for p in (.025,.975)]
 cells.append({'cell':cell,'selected_pairs':selected,'pair_ratios':ratios,'speed_ratio':statistics.median(ratios) if ratios else None,'bootstrap_95':interval,'off_seconds_median':statistics.median(off) if off else None,'on_seconds_median':statistics.median(on) if on else None,'work_totals':dict(totals),'accepted_prefix_fraction':totals['spec_accepted_draft_tokens']/totals['spec_proposed_draft_tokens'] if totals['spec_proposed_draft_tokens'] else None,'emitted_per_row_cycle':totals['spec_committed_tokens']/totals['spec_cycles'] if totals['spec_cycles'] else None})
pytest={}
if (root/'pytest.xml').exists():
 suites=ET.parse(root/'pytest.xml').getroot()
 for k in ['tests','failures','errors','skipped']:pytest[k]=sum(int(s.get(k,0)) for s in suites.iter('testsuite'))
 pytest['passed']=pytest['tests']-pytest['failures']-pytest['errors']-pytest['skipped']
summary={'revision':plan['revision'],'successful_processes':len(runs),'samples':sum(len(d['records']) for d in runs.values()),'excluded_samples':excluded,'greedy_mismatches':greedy_mismatches,'route_failures':route_failures,'five_pair_gate':all(len(c['selected_pairs'])==5 for c in cells),'cells':cells,'pytest':pytest,'calibration':{'median_bandwidth_bytes_per_second':statistics.median(d['calibration']['bandwidth_bytes_per_second'] for d in runs.values()),'median_bf16_flops_per_second':statistics.median(d['calibration']['bf16_flops_per_second'] for d in runs.values())}}
summary['qualification_passed']=summary['five_pair_gate'] and not greedy_mismatches and not route_failures
summary['credible_acceleration_cells']=[c['cell'] for c in cells if c['bootstrap_95'] and c['bootstrap_95'][0]>1]
with (root/'analysis.json').open('x') as f:json.dump(summary,f,indent=2);f.write('\n')
text=f"# Fresh five-pair performance qualification — 2026-09-09\n\nSource: `{plan['revision']}`. Qwen3-4B target / Qwen3-0.6B draft, current fast graph mode, fixed K=4, A100-SXM4-40GB.\n\n"
text+=f"Completed {len(runs)} successful fresh processes and {summary['samples']} timed samples; {len(excluded)} samples excluded under the preregistered rules. Five valid pairs in every cell: {summary['five_pair_gate']}. Greedy output mismatches: {len(greedy_mismatches)}. Active/bypass route failures: {len(route_failures)}. Cells with descriptive 95% interval entirely above 1: {len(summary['credible_acceleration_cells'])}.\n\n"
text+='Ratio = speculation-off / speculation-on wall time; above 1 means faster with speculation. Each pair contributes the median of three matched-seed ratios. Exact 95% bootstrap intervals resample five process pairs (3125 combinations).\n\n| Batch | Context | Sampling | Off/on ratio | 95% interval | Off ms | On ms |\n| ---: | ---: | --- | ---: | --- | ---: | ---: |\n'
for c in cells:
 b,n,f,_,_=c['cell'];ci=c['bootstrap_95'];ci_text=f"{ci[0]:.3f}–{ci[1]:.3f}" if ci else 'incomplete'
 text+=f"| {b} | {n} | {f} | {c['speed_ratio']:.3f} | {ci_text} | {1000*c['off_seconds_median']:.1f} | {1000*c['on_seconds_median']:.1f} |\n"
text+='\nB=8 is whole-batch bypass with draft resources resident. B=1/4 must execute speculative cycles. Greedy controls are compared within graph fast mode; same-seed stochastic token identity is not required. Warmups permit prefix cache hits: this is a warmed synthetic workload, not cold serving or a production tail-latency claim. Boundary hardware snapshots cannot continuously prove exclusive occupancy. Historical old/current off-regression and extended matrices are outside this registered primary qualification.\n\n'
text+=f"Full pytest ran after timing: {pytest}. Exit code: {status.get('pytest_exit_code')}. See `pytest.log` and `pytest.xml`.\n\nRaw pairs, process logs, `plan.json`, `status.json`, `analysis.json`, model/environment verification, and orchestration/analysis scripts are retained here. `analysis.json` includes selected pair IDs, all rejected samples, acceptance-prefix statistics, emitted tokens per row-cycle, and fresh roof calibration.\n"
with (root/'README.md').open('x') as f:f.write(text)
print(json.dumps({k:v for k,v in summary.items() if k!='cells'},indent=2))
