import datetime, hashlib, json, os, pathlib, subprocess, sys
root=pathlib.Path(__file__).resolve().parent
repo=pathlib.Path('/workspace/nano-vllm')
python='/workspace/venvs/nano-vllm/bin/python'
revision=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
assert not subprocess.check_output(['git','status','--porcelain'],cwd=repo,text=True).strip()
env=os.environ.copy()
env.update(PYTHONDONTWRITEBYTECODE='1',PYTHONPATH=str(repo),HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',CUDA_VISIBLE_DEVICES='0',NANOVLLM_TEST_TOKENIZER_PATH='/workspace/models/Qwen3-0.6B')
plan={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'revision':revision,'comparison':'current fast graph speculation off versus on; fixed K=4','suite':'primary','pairs':[['off','on'],['on','off'],['off','on'],['on','off'],['off','on']],'repair':'If any cell lacks five complete accepted pairs, append one full pair 5 in on/off order; use first five valid pair IDs per cell. No latency-based exclusions.','seeds':[17,23,41],'warmups':2,'scope':'30 primary cells; B=1/4/8, context=32/256, five sampling families, 64 output tokens. Does not rerun historical old/current off-regression or supplemental matrix.','after_performance':'full CUDA-enabled pytest suite','harness_sha256':hashlib.sha256((repo/'tests/run_speculative_v7_benchmark.py').read_bytes()).hexdigest()}
(root/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
status={'runs':[]}
def save(): (root/'status.json').write_text(json.dumps(status,indent=2)+'\n')
def run(cmd,log,extra=None):
 e=env.copy();e.update(extra or {})
 with (root/log).open('x') as f:
  return subprocess.run(cmd,cwd=repo,env=e,stdout=f,stderr=subprocess.STDOUT).returncode
for label,cmd in [('models',[python,'deployment/a100-2026-09-09/download_models.py','--verify-only']),('environment',[python,'deployment/a100-2026-09-09/check_environment.py','--output',str(root/'environment.json')])]:
 rc=run(cmd,label+'.log');assert rc==0,(label,rc)
def complete_counts():
 counts={}
 for pair in range(6):
  paths=[root/f'pair{pair:02d}-{side}.json' for side in ['off','on']]
  if not all(p.exists() for p in paths): continue
  reports=[json.loads(p.read_text()) for p in paths]
  def key(r): return (r['batch'],r['context'],r['family'],r['consumer'],r['completion'])
  for cell in {key(r) for r in reports[0]['records']}:
   groups=[[r for r in d['records'] if key(r)==cell] for d in reports]
   if all(len(g)==3 and {r['seed'] for r in g}=={17,23,41} and all(r['accepted'] for r in g) for g in groups): counts[cell]=counts.get(cell,0)+1
 return counts
for pair in range(6):
 if pair==5:
  counts=complete_counts()
  if len(counts)==30 and min(counts.values())>=5: break
 order=['off','on'] if pair%2==0 else ['on','off']
 for side in order:
  name=f'pair{pair:02d}-{side}'
  print('START',name,datetime.datetime.now(datetime.timezone.utc).isoformat(),flush=True)
  cmd=[python,'tests/run_speculative_v7_benchmark.py','--model','/workspace/models/Qwen3-4B','--draft-model','/workspace/models/Qwen3-0.6B','--revision',revision,'--mode','graph','--suite','primary','--pair',str(pair),'--output',str(root/(name+'.json'))]
  if side=='on':cmd.append('--enabled')
  rc=run(cmd,name+'.log',{'TORCHINDUCTOR_CACHE_DIR':str(root/(name+'-inductor-cache')),'TRITON_CACHE_DIR':str(root/(name+'-triton-cache'))})
  record={'pair':pair,'side':side,'exit_code':rc}
  if rc==0:
   d=json.loads((root/(name+'.json')).read_text());record.update(samples=len(d['records']),accepted=sum(r['accepted'] for r in d['records']))
  status['runs'].append(record);save();print('FINISH',json.dumps(record),flush=True)
counts=complete_counts();status['five_valid_pairs_all_cells']=len(counts)==30 and min(counts.values())>=5;save()
print('PERFORMANCE FINISHED; START PYTEST',flush=True)
rc=run([python,'-m','pytest','-q','-p','no:cacheprovider','--junitxml='+str(root/'pytest.xml')],'pytest.log',{'TORCHINDUCTOR_CACHE_DIR':str(root/'pytest-inductor-cache'),'TRITON_CACHE_DIR':str(root/'pytest-triton-cache')})
status['pytest_exit_code']=rc;save();print('PYTEST FINISHED',rc,flush=True)
