# Fresh five-pair performance qualification — 2026-09-09

Source: `74eac2f9512e737d7eb1f6a1d2c97eebb5efc9ee`. Qwen3-4B target / Qwen3-0.6B draft, current fast graph mode, fixed K=4, A100-SXM4-40GB.

Completed 10 successful fresh processes and 900 timed samples; 0 samples excluded under the preregistered rules. Five valid pairs in every cell: True. Greedy output mismatches: 0. Active/bypass route failures: 0. Cells with descriptive 95% interval entirely above 1: 8.

Observed performance: eight cells show descriptive 95% intervals entirely above 1, with 1.17–1.28× throughput. These are B1 plain/top-p at both contexts, B1 top-k/combined at context 256, and B4 plain/top-p at context 256. Active greedy cells are 1.42–1.62× slower. B8 bypass adds 2.6–4.1% wall-time overhead. The results support gains in these tested workloads, not a universal speedup claim.

Full pytest: **1,080 passed, 1 skipped, 14 deprecation warnings in 187.88 seconds**. No runtime edits were needed.

Ratio = speculation-off / speculation-on wall time; above 1 means faster with speculation. Each pair contributes the median of three matched-seed ratios. Exact 95% bootstrap intervals resample five process pairs (3125 combinations).

| Batch | Context | Sampling | Off/on ratio | 95% interval | Off ms | On ms |
| ---: | ---: | --- | ---: | --- | ---: | ---: |
| 1 | 32 | combined | 0.829 | 0.807–0.854 | 569.7 | 683.6 |
| 1 | 32 | greedy | 0.630 | 0.625–0.631 | 535.6 | 851.4 |
| 1 | 32 | plain | 1.278 | 1.224–1.386 | 548.8 | 438.2 |
| 1 | 32 | topk | 0.809 | 0.793–0.864 | 554.4 | 684.1 |
| 1 | 32 | topp | 1.257 | 1.213–1.272 | 563.3 | 450.4 |
| 1 | 256 | combined | 1.181 | 1.166–1.192 | 579.1 | 489.8 |
| 1 | 256 | greedy | 0.704 | 0.701–0.713 | 545.9 | 774.9 |
| 1 | 256 | plain | 1.268 | 1.247–1.302 | 558.9 | 443.2 |
| 1 | 256 | topk | 1.210 | 1.179–1.316 | 564.2 | 466.1 |
| 1 | 256 | topp | 1.273 | 1.256–1.282 | 573.2 | 453.5 |
| 4 | 32 | combined | 0.680 | 0.669–0.723 | 592.5 | 870.5 |
| 4 | 32 | greedy | 0.619 | 0.608–0.633 | 535.8 | 871.0 |
| 4 | 32 | plain | 0.903 | 0.887–0.907 | 548.4 | 609.7 |
| 4 | 32 | topk | 0.685 | 0.664–0.695 | 555.0 | 812.2 |
| 4 | 32 | topp | 0.989 | 0.960–1.014 | 586.6 | 592.7 |
| 4 | 256 | combined | 0.938 | 0.891–0.976 | 644.8 | 686.6 |
| 4 | 256 | greedy | 0.696 | 0.692–0.698 | 586.8 | 844.2 |
| 4 | 256 | plain | 1.171 | 1.159–1.201 | 599.0 | 516.7 |
| 4 | 256 | topk | 0.878 | 0.852–0.882 | 604.1 | 695.6 |
| 4 | 256 | topp | 1.187 | 1.158–1.206 | 636.0 | 540.3 |
| 8 | 32 | combined | 0.968 | 0.962–0.974 | 606.3 | 626.0 |
| 8 | 32 | greedy | 0.961 | 0.953–0.970 | 541.9 | 564.1 |
| 8 | 32 | plain | 0.966 | 0.939–0.973 | 556.1 | 575.8 |
| 8 | 32 | topk | 0.966 | 0.962–0.975 | 564.2 | 581.3 |
| 8 | 32 | topp | 0.967 | 0.959–0.971 | 599.8 | 619.3 |
| 8 | 256 | combined | 0.972 | 0.968–0.984 | 693.6 | 716.4 |
| 8 | 256 | greedy | 0.972 | 0.951–0.978 | 631.4 | 651.6 |
| 8 | 256 | plain | 0.967 | 0.964–0.980 | 643.5 | 666.0 |
| 8 | 256 | topk | 0.973 | 0.966–0.986 | 652.7 | 671.0 |
| 8 | 256 | topp | 0.974 | 0.967–0.977 | 690.3 | 709.4 |

B=8 is whole-batch bypass with draft resources resident. B=1/4 must execute speculative cycles. Greedy controls are compared within graph fast mode; same-seed stochastic token identity is not required. Warmups permit prefix cache hits: this is a warmed synthetic workload, not cold serving or a production tail-latency claim. Boundary hardware snapshots cannot continuously prove exclusive occupancy. Historical old/current off-regression and extended matrices are outside this registered primary qualification.

Full pytest ran after timing: {'tests': 1081, 'failures': 0, 'errors': 0, 'skipped': 1, 'passed': 1080}. Exit code: 0. See `pytest.log` and `pytest.xml`.

Raw pairs, process logs, `plan.json`, `status.json`, `analysis.json`, model/environment verification, and orchestration/analysis scripts are retained here. `analysis.json` includes selected pair IDs, all rejected samples, acceptance-prefix statistics, emitted tokens per row-cycle, and fresh roof calibration.
