import collections
import hashlib
import json
from pathlib import Path
import subprocess

root = Path(__file__).resolve().parent
repo = Path('/workspace/nano-vllm')
revision = subprocess.check_output(['git', '-C', str(repo), 'rev-parse', 'HEAD'], text=True).strip()
assert not subprocess.check_output(['git', '-C', str(repo), 'status', '--porcelain'], text=True).strip()
environment = json.loads((root / 'environment.json').read_text())
assert environment['passed'] and environment['source_commit'] == revision
reports = {}
for name, mode, numerical in [('graph-fast', 'graph', 'fast'), ('eager-invariant', 'eager', 'invariant')]:
    report = json.loads((root / f'{name}.json').read_text())
    assert report['revision'] == revision
    assert report['args']['mode'] == mode and report['args']['numerical_mode'] == numerical
    assert report['args']['enabled'] and report['args']['sweep']
    assert report['args']['model'] == '/workspace/models/Qwen3-4B'
    assert report['args']['draft_model'] == '/workspace/models/Qwen3-0.6B'
    for file, digest in report['source_sha256'].items():
        assert hashlib.sha256((repo / file).read_bytes()).hexdigest() == digest
    for field, model in [('model_files', 'Qwen3-4B'), ('draft_model_files', 'Qwen3-0.6B')]:
        verified = json.loads((Path('/workspace/models/.verification') / f'{model}.json').read_text())
        # Compare matching target/draft identities across reports below; the pinned
        # checkpoint verifier was run before both processes.
        assert verified['revision']
    assert report['failure_retry'] and report['causality_probe']
    assert report['pending_before_close'] > 0 and report['abandoned_pending'] > 0
    assert report['forced_metrics']['spec_residual_numerical_fallbacks'] == 1
    assert report['completed_metrics']['spec_residual_numerical_fallbacks'] == 0
    assert all(r['cache_repeat'] and r['stream_parity'] for r in report['results'])
    assert report['mixed_sample_lengths'] == [13] * 4
    assert report['stochastic_lengths'] == [13] * 4
    expected_cells = {(b, k, s) for b in range(1, 5) for k in range(1, 5) for s in ['greedy', 'plain', 'topk', 'topp', 'combined']}
    assert {(c['batch'], c['k'], c['sampling']) for c in report['sweep_cells']} == expected_cells
    assert all(c['cycles'] > 0 for c in report['sweep_cells'])
    assert report['cycles'] and all(not c['compile_delta'] for c in report['cycles'])
    reports[name] = report
assert reports['graph-fast']['model_files'] == reports['eager-invariant']['model_files']
assert reports['graph-fast']['draft_model_files'] == reports['eager-invariant']['draft_model_files']
summary = {'passed': True, 'revision': revision, 'runs': {}}
for name, r in reports.items():
    summary['runs'][name] = {'cycles': len(r['cycles']), 'sweep_cells': len(r['sweep_cells']), 'verifiers': dict(collections.Counter(c['verifier'] for c in r['cycles'])), 'per_cycle_compile_changes': 0, 'failure_retry': True, 'causality_probe': True, 'pending_before_close': r['pending_before_close'], 'abandoned_pending': r['abandoned_pending']}
with (root / 'summary.json').open('x') as f:
    json.dump(summary, f, indent=2)
    f.write('\n')
text = '# Target/draft speculative lifecycle smokes — 2026-09-09\n\nPASS on Qwen3-4B target / Qwen3-0.6B draft, A100-SXM4-40GB. Both fresh processes exited 0.\n\n'
text += f'Source commit: `{revision}`. Pinned models and environment verified before execution.\n\n'
text += '| Mode | Speculative cycles | Sweep cells | Result |\n| --- | ---: | ---: | --- |\n'
for name, r in summary['runs'].items():
    text += f"| {name} | {r['cycles']} | {r['sweep_cells']} | Pass |\n"
text += '\nCoverage: batches 1–4, K=1–4, greedy/plain/top-k/top-p/combined sampling; prompt lengths around 256-token block boundaries; repeated-prefix and stream token/text parity; pending-burst cancellation; close-before-first-step; abandoned-session cleanup and engine-lease reuse; completion metrics; future-token causality; forced residual fallback; injected post-verifier failure with state/RNG rollback and identical retry; memory budget assertions and top-p scratch checks.\n\nEvery recorded cycle had unchanged compiler counters. Runs use separate fresh compiler cache directories. These were lifecycle smokes (`--retained` was not enabled), not full compiler-artifact certification or performance qualification. No ordinary-decoder baseline or cross-mode token equivalence is claimed.\n\n'
text += 'Reproduce from `/workspace/nano-vllm`, with the pinned venv activated, `PYTHONPATH=/workspace/nano-vllm`, offline Hugging Face settings, CUDA device 0, and distinct fresh `TORCHINDUCTOR_CACHE_DIR`/`TRITON_CACHE_DIR` per process:\n\n```bash\n'
for name, r in reports.items():
    a = r['args']
    text += f"python tests/run_speculative_v5_gpu.py --model {a['model']} --draft-model {a['draft_model']} --mode {a['mode']} --numerical-mode {a['numerical_mode']} --enabled --sweep --output /NEW_OUTPUT_DIRECTORY/{name}.json\n"
text += '```\n\nRaw JSON reports include source/model hashes, environment, cycles, metrics, and memory audits. Logs and SHA256SUMS are retained alongside this summary. Repository source remained unchanged.\n'
with (root / 'README.md').open('x') as f:
    f.write(text)
with (root / 'SHA256SUMS').open('x') as f:
    for p in sorted(root.iterdir()):
        if p.is_file() and p.name != 'SHA256SUMS':
            f.write(f'{hashlib.sha256(p.read_bytes()).hexdigest()}  {p.name}\n')
print(json.dumps(summary, indent=2))
