# Target/draft speculative lifecycle smokes — 2026-09-09

PASS on Qwen3-4B target / Qwen3-0.6B draft, A100-SXM4-40GB. Both fresh processes exited 0.

Source commit: `74eac2f9512e737d7eb1f6a1d2c97eebb5efc9ee`. Pinned models and environment verified before execution.

| Mode | Speculative cycles | Sweep cells | Result |
| --- | ---: | ---: | --- |
| graph-fast | 254 | 80 | Pass |
| eager-invariant | 248 | 80 | Pass |

Coverage: batches 1–4, K=1–4, greedy/plain/top-k/top-p/combined sampling; prompt lengths around 256-token block boundaries; repeated-prefix and stream token/text parity; pending-burst cancellation; close-before-first-step; abandoned-session cleanup and engine-lease reuse; completion metrics; future-token causality; forced residual fallback; injected post-verifier failure with state/RNG rollback and identical retry; memory budget assertions and top-p scratch checks.

Every recorded cycle had unchanged compiler counters. Runs use separate fresh compiler cache directories. These were lifecycle smokes (`--retained` was not enabled), not full compiler-artifact certification or performance qualification. No ordinary-decoder baseline or cross-mode token equivalence is claimed.

Reproduce from `/workspace/nano-vllm`, with the pinned venv activated, `PYTHONPATH=/workspace/nano-vllm`, offline Hugging Face settings, CUDA device 0, and distinct fresh `TORCHINDUCTOR_CACHE_DIR`/`TRITON_CACHE_DIR` per process:

```bash
python tests/run_speculative_v5_gpu.py --model /workspace/models/Qwen3-4B --draft-model /workspace/models/Qwen3-0.6B --mode graph --numerical-mode fast --enabled --sweep --output /NEW_OUTPUT_DIRECTORY/graph-fast.json
python tests/run_speculative_v5_gpu.py --model /workspace/models/Qwen3-4B --draft-model /workspace/models/Qwen3-0.6B --mode eager --numerical-mode invariant --enabled --sweep --output /NEW_OUTPUT_DIRECTORY/eager-invariant.json
```

Raw JSON reports include source/model hashes, environment, cycles, metrics, and memory audits. Logs and SHA256SUMS are retained alongside this summary. Repository source remained unchanged.
