"""Validate and analyze the full bounded speculative-decoding verification."""
import collections,hashlib,itertools,json,pathlib,statistics,subprocess,xml.etree.ElementTree as ET
root=pathlib.Path(__file__).resolve().parent;repo=pathlib.Path('/workspace/nano-vllm')
plan=json.loads((root/'plan.json').read_text());status=json.loads((root/'benchmark-status.json').read_text())
def read(name):return json.loads((root/name).read_text())
def key(r):return tuple(r[k] for k in ('batch','context','family','consumer','completion'))
def interval(values):
 samples=sorted(statistics.median(x) for x in itertools.product(values,repeat=5))
 return [samples[int((len(samples)-1)*q)] for q in (.025,.975)]
runs={};rejected=[];mismatches=[]
anchor=json.loads(pathlib.Path('/workspace/verification/performance-five-pair-arrival/pair00-on.json').read_text())
for item in status['runs']:
 name=item['name'];p=root/(name+'.json')
 if item['exit_code'] or not p.exists() or name.startswith('auto-kv'):continue
 d=read(name+'.json')
 if 'records' not in d:continue
 assert d['models']==anchor['models']
 side='before' if name.endswith('-before') else 'after'
 assert d['runtime_revision']==plan[side+'_revision']
 assert d['harness_sha256']==anchor['harness_sha256']
 source=root/'baseline' if side=='before' else repo
 for filename,sha in d['source_sha256'].items():assert hashlib.sha256((source/filename).read_bytes()).hexdigest()==sha
 assert d['warmups_per_cell']==2 and d['seeds']==[17,23,41]
 assert len({key(r)+(r['seed'],) for r in d['records']})==len(d['records'])
 for r in d['records']:
  assert len(r['outputs'])==r['batch'] and all(len(o['token_ids'])==r['completion'] for o in r['outputs'])
  assert r['seconds']>0 and r['accepted']==(not r['rejection_reasons'])
  if not r['accepted']:rejected.append({'run':name,'cell':key(r),'seed':r['seed'],'reasons':r['rejection_reasons']})
 runs[name]=d
results={}
for prefix in ('active','off'):
 expected={(b,c,f,'generate',64) for b in (1,4,8) for c in ((32,256) if prefix=='active' else (32,)) for f in (('greedy','plain','topk','topp','combined') if prefix=='active' else ('plain',))}
 for name,d in runs.items():
  if name.startswith(prefix+'-p'):
   assert {key(r) for r in d['records']}==expected and len(d['records'])==len(expected)*3
   assert d['args']['enabled']==(prefix=='active')
 cells=[]
 for cell in sorted(expected):
  selected=[];ratios=[];old=[];new=[];work={s:collections.Counter() for s in ('before','after')}
  for pair in range(6):
   names=[f'{prefix}-p{pair}-{s}' for s in ('before','after')]
   if not all(n in runs for n in names):continue
   a,b=[{r['seed']:r for r in runs[n]['records'] if key(r)==cell} for n in names]
   for seed in (17,23,41):
    if prefix=='off' or cell[2]=='greedy':
     if [o['token_ids'] for o in a[seed]['outputs']]!=[o['token_ids'] for o in b[seed]['outputs']]:mismatches.append({'prefix':prefix,'pair':pair,'cell':cell,'seed':seed})
   if not all(r['accepted'] for r in (*a.values(),*b.values())):continue
   if len(selected)==5:continue
   assert runs[names[0]]['args']['pair']==runs[names[1]]['args']['pair']==pair
   order=names if pair%2==0 else names[::-1]
   assert runs[order[0]]['samples_finished_ns']<runs[order[1]]['process_started_ns']
   selected.append(pair);ratios.append(statistics.median(a[s]['seconds']/b[s]['seconds'] for s in (17,23,41)))
   old.extend(r['seconds'] for r in a.values());new.extend(r['seconds'] for r in b.values())
   for side,rows in [('before',a),('after',b)]:
    for r in rows.values():
     cycles=sum(o['metrics'].get('spec_cycles',0) for o in r['outputs'])
     assert (cycles>0)==(prefix=='active' and cell[0]<=4)
     for o in r['outputs']:
      for k,v in o['metrics'].items():
       if k.startswith('spec_'):work[side][k]+=v
  cells.append({'cell':cell,'pairs':selected,'ratios':ratios,'before_after_speed_ratio':statistics.median(ratios) if ratios else None,'bootstrap_95':interval(ratios) if len(ratios)==5 else None,'before_ms':1000*statistics.median(old) if old else None,'after_ms':1000*statistics.median(new) if new else None,'work':{s:dict(w) for s,w in work.items()}})
 results[prefix]=cells
controls=read('matching-controls.json');assert all(c['passed'] for c in controls)
strict=read('graph-fast-on.json');assert strict['args']['retained'] and len(strict['sweep_cells'])==80
assert all(c['compiler_unchanged'] and not c['compile_delta'] for c in strict['cycles'])
assert read('acceptance-fix-reproduction.json')['passed'];assert read('adaptive-gpu.json')['passed']
for name,d in runs.items():
 if name.startswith(('extended-','configured-')):
  assert all(len(o['token_ids'])==r['completion'] for r in d['records'] for o in r['outputs'])
 if name=='extended-on':
  for r in d['records']:
   cycles=sum(o['metrics'].get('spec_cycles',0) for o in r['outputs'])
   if r['batch']>4:assert cycles==0
if 'extended-on' in runs and 'extended-off' in runs:assert {key(r)+(r['seed'],) for r in runs['extended-on']['records']}=={key(r)+(r['seed'],) for r in runs['extended-off']['records']}
pytest={}
if (root/'pytest.xml').exists():
 tree=ET.parse(root/'pytest.xml').getroot()
 for k in ('tests','failures','errors','skipped'):pytest[k]=sum(int(x.get(k,0)) for x in tree.iter('testsuite'))
 pytest['passed']=pytest['tests']-pytest['failures']-pytest['errors']-pytest['skipped']
summary={'before_revision':plan['before_revision'],'after_revision':plan['after_revision'],'paired_results':results,'mismatches':mismatches,'rejected_samples':rejected,'timed_samples':sum(len(d['records']) for d in runs.values()),'failed_runs':[r for r in status['runs'] if r['exit_code']],'automatic_kv_before':read('auto-kv-probe-before.json')['initialized'],'automatic_kv_after':read('auto-kv-probe-after.json')['initialized'],'full_verification_passed':False,'fixed_kv_pair_gate':all(len(c['pairs'])==5 for cs in results.values() for c in cs) and not mismatches,'pytest':pytest,'strict_cycles':len(strict['cycles']),'strict_sweep_cells':len(strict['sweep_cells']),'matching_controls':controls,'supplemental_runs':{n:{'samples':len(d['records']),'accepted':sum(r['accepted'] for r in d['records'])} for n,d in runs.items() if n.startswith(('extended-','configured-'))}}
with (root/'analysis.json').open('x') as f:json.dump(summary,f,indent=2);f.write('\n')
text='# Speculative decoding: full bounded verification and before/after benchmark\n\n'
text+='The earlier primary benchmark exercised complete speculative decoding across sampling families. It compared repaired speculation-on with repaired ordinary decoding. This run additionally measures the repair/optimization bundle directly against its pre-fix runtime.\n\n'
text+=f"Before: `{plan['before_revision']}`. After: `{plan['after_revision']}`. Qwen3-4B target / Qwen3-0.6B draft, BF16, one A100-SXM4-40GB, TP1, exact sampling.\n\n"
text+='**Overall verification is not fully passing: automatic KV sizing regressed.** The matched batch-5 constructor succeeds before the bundle and fails afterward with an 18,972,055-byte modeled headroom shortfall. Current batch-4 automatic sizing also failed (30,621,612-byte shortfall). The audit refuses initialization safely. Fixed 64-block configurations pass the lifecycle and performance paths. No runtime changes were made during this evaluation.\n\n'
text+='The new persistent speculative buffers occupy 24,310,112 bytes in the matched constructor probe. Code inspection shows they are allocated after KV sizing; the final audit subtracts the full workspace reservation after these buffers are resident. This is a likely accounting contributor, not a separately repaired/validated root-cause claim. See `auto-kv-probe-before.json`, `auto-kv-probe-after.json`, and failed automatic-KV logs.\n\n'
text+=f"Correctness evidence: strict graph compiler/cache/capture checks passed for {len(strict['cycles'])} cycles and 80 sweep cells; graph-fast, eager-fast, and eager-invariant matched ordinary controls; lifecycle cancellation, abandonment, rollback/retry, causality and scratch-memory checks passed in fixed-KV runs. The one-ULP regression reproduced the pre-review trusted path incorrectly accepting one proposal while the repaired path and validated reference reject it. That dirty pre-review snapshot is distinct from the pre-optimization performance baseline. Adaptive GPU routing checks passed with explicitly synthetic calibration fixtures; they are not adaptive performance evidence. The previous full Qwen3-4B invariant numerical matrix is linked in `plan.json`.\n\n"
text+='Direct before/after timing: 5 process pairs AB/BA/AB/BA/AB; 2 warmups and seeds 17/23/41 per cell. Ratios are before wall time / after wall time, so above 1 means the repair bundle is faster. Each pair contributes its median of 3 seed ratios; exact descriptive 95% bootstrap resamples the five process pairs. This does not isolate individual edits.\n\n'
for prefix,title in [('active','Speculation enabled before and after'),('off','Speculation disabled regression control')]:
 text+=f'## {title}\n\n| Batch | Context | Sampling | Before/after ratio | 95% interval | Before ms | After ms |\n| ---: | ---: | --- | ---: | --- | ---: | ---: |\n'
 for c in results[prefix]:
  b,n,f,_,_=c['cell'];ci=c['bootstrap_95'];ci_text=f'{ci[0]:.3f}–{ci[1]:.3f}' if ci else 'incomplete'
  text+=f"| {b} | {n} | {f} | {c['before_after_speed_ratio']:.3f} | {ci_text} | {c['before_ms']:.1f} | {c['after_ms']:.1f} |\n"
text+=f"\nGreedy/ordinary-control mismatch records: {len(mismatches)}. Excluded timing samples: {len(rejected)}. Raw reports retain all selections, work counters, hashes, hardware boundary snapshots, and calibration roofs.\n\nFull pytest after these benchmarks: {pytest}.\n\n"
text+='Existing repaired on/off five-pair performance results: [report](../performance-five-pair-arrival/README.md). Strict and ordinary controls, adaptive checks, automatic-sizing failures, before/after pairs, extended workloads, configured-K cap checks and JUnit results are retained here. This covers the documented single-GPU Qwen3 envelope, not all models, production traffic, TP>1, FlashInfer speculation, or an independently calibrated adaptive speedup claim. Extended/cap timings have one process per side and do not carry five-pair confidence. All timings use warmed synthetic prompts; prefix-cache hits are possible.\n'
with (root/'README.md').open('x') as f:f.write(text)
print(json.dumps({k:v for k,v in summary.items() if k!='paired_results'},indent=2))
