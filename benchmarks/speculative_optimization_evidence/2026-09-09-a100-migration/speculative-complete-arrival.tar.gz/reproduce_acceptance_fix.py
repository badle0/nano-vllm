"""Reproduce the one-ULP trusted-acceptance bug from the preserved pre-review snapshot."""
import hashlib,importlib.util,json,pathlib,sys,tarfile
import torch
root=pathlib.Path(__file__).resolve().parent
archive=pathlib.Path('/workspace/nano-vllm-review-snapshots/2026-09-08-pre-risk-review-198e1e6/source.tar.gz')
with tarfile.open(archive) as tar:
 matches=[m for m in tar.getmembers() if m.name.endswith('nanovllm/layers/sampler.py')]
 assert len(matches)==1
 raw=tar.extractfile(matches[0]).read()
before=root/'pre-risk-sampler.py';before.write_bytes(raw)
def load(name,path):
 spec=importlib.util.spec_from_file_location(name,path);module=importlib.util.module_from_spec(spec);sys.modules[name]=module;spec.loader.exec_module(module);return module
old=load('pre_risk_sampler',before).ModifiedRejectionSampler()
new=load('repaired_sampler',pathlib.Path('/workspace/nano-vllm/nanovllm/layers/sampler.py')).ModifiedRejectionSampler()
p=torch.tensor([[[.1,.2,.7000001]]],dtype=torch.float32);q=torch.tensor([[[.1,.2,.6999998]]],dtype=torch.float32)
tokens=torch.tensor([[0]],dtype=torch.int64);u=torch.nextafter(torch.tensor([[1.]]),torch.tensor([[0.]]));noise=torch.ones(1,3,dtype=torch.float32)
kwargs={'uniforms':u,'correction_noise':noise}
from unittest.mock import patch
# The older API has no injected-uniform argument. Replace only its draw,
# preserving the archived implementation and acceptance arithmetic.
with patch("torch.rand", return_value=u):
 a=old.accept_trusted(p,tokens,q)
b=new.accept_trusted(p,tokens,q,**kwargs);ref=new.accept(p,tokens,q,**kwargs)
assert a.accepted_counts.tolist()==[1]
assert b.accepted_counts.tolist()==ref.accepted_counts.tolist()==[0]
report={'passed':True,'pre_review_snapshot_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'pre_review_sampler_sha256':hashlib.sha256(raw).hexdigest(),'current_sampler_sha256':hashlib.sha256(pathlib.Path('/workspace/nano-vllm/nanovllm/layers/sampler.py').read_bytes()).hexdigest(),'old_trusted_accepted_counts':a.accepted_counts.tolist(),'repaired_trusted_accepted_counts':b.accepted_counts.tolist(),'validated_reference_accepted_counts':ref.accepted_counts.tolist(),'scope':'CPU deterministic one-ULP boundary; pre-review optimized dirty snapshot is distinct from the pre-optimization 198e1e6 performance baseline.'}
with (root/'acceptance-fix-reproduction.json').open('x') as f:json.dump(report,f,indent=2)
print(json.dumps(report,indent=2))
