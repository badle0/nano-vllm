"""GPU functional routing checks using deliberately synthetic calibration fixtures."""
import hashlib,json,pathlib,subprocess
import torch
from nanovllm import LLM,SamplingParams
root=pathlib.Path(__file__).resolve().parent
source={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(pathlib.Path('nanovllm').rglob('*.py'))}
llm=LLM('/workspace/models/Qwen3-4B',draft_model='/workspace/models/Qwen3-0.6B',num_speculative_tokens=4,speculative_policy='adaptive',max_num_seqs=5,max_num_batched_tokens=1024,max_model_len=512,num_kvcache_blocks=64,gpu_memory_utilization=.5,enforce_eager=False)
results={}
def generate(name,temperature=.8,batch=1,max_tokens=17):
 torch.manual_seed(917)
 outputs=llm.generate([[51+i]*32 for i in range(batch)],SamplingParams(temperature=temperature,max_tokens=max_tokens,ignore_eos=True),use_tqdm=False)
 assert all(len(o['token_ids'])==max_tokens for o in outputs)
 assert llm.is_finished() and not llm.scheduler.block_manager.used_block_ids
 assert not llm.scheduler.block_manager._active_temporary_reservations and llm.scheduler._active_spec_transaction is None
 results[name]={'outputs':outputs,'routing':llm.speculative_routing_metrics(),'cycles':sum(o['metrics'].get('spec_cycles',0) for o in outputs)}
 return results[name]
def calibration(winning):
 return [dict(batch_size=1,sampling_family=family,context_bucket=context,catchup_bucket=catchup,k=k,ordinary_ms_per_token=100. if winning else 1.,cycle_ms=1. if winning else 100.,expected_committed_tokens=k+1.) for family in ('temperature','greedy') for context in (32,64,128,256,512) for catchup in (0,1,2,4,8,16,32,64,128,256,512) for k in (1,2,3,4)]
try:
 unknown=generate('unknown');assert unknown['cycles']==0
 assert unknown['routing']['decision_counts'].get('bypass_uncalibrated_route',0)>0
 llm.load_speculative_calibration(calibration(False));losing=generate('losing');assert losing['cycles']==0
 assert losing['routing']['decision_counts'].get('bypass_below_10_percent_gate',0)>0
 assert [o['token_ids'] for o in unknown['outputs']]==[o['token_ids'] for o in losing['outputs']]
 llm.load_speculative_calibration(calibration(True));winning=generate('winning');assert winning['cycles']>0
 assert any(k.startswith('chosen_k_') and v>0 for k,v in winning['routing']['decision_counts'].items())
 llm.load_speculative_calibration(calibration(True));greedy=generate('fast_greedy',temperature=0.);assert greedy['cycles']==0
 assert greedy['routing']['decision_counts'].get('bypass_fast_greedy_sequential_verifier',0)>0
 assert generate('batch5_bypass',batch=5)['cycles']==0
 assert generate('one_token_tail',max_tokens=1)['cycles']==0
 report={'passed':True,'purpose':'Functional adaptive routing only; synthetic winning/losing fixtures are not performance calibration or evidence of adaptive speedup.','revision':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'source_sha256':source,'gpu':torch.cuda.get_device_name(),'torch':torch.__version__,'results':results}
 with (root/'adaptive-gpu.json').open('x') as f:json.dump(report,f,indent=2)
 print('PASS adaptive GPU functional routing',flush=True)
finally:llm.exit()
