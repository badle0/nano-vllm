# Speculative decoding: full bounded verification and before/after benchmark

The earlier primary benchmark exercised complete speculative decoding across sampling families. It compared repaired speculation-on with repaired ordinary decoding. This run additionally measures the repair/optimization bundle directly against its pre-fix runtime.

Before: `198e1e6a084dfb1f59d178a8ca3bdc1d0b094bed`. After: `74eac2f9512e737d7eb1f6a1d2c97eebb5efc9ee`. Qwen3-4B target / Qwen3-0.6B draft, BF16, one A100-SXM4-40GB, TP1, exact sampling.

**Overall verification is not fully passing: automatic KV sizing regressed.** The matched batch-5 constructor succeeds before the bundle and fails afterward with an 18,972,055-byte modeled headroom shortfall. Current batch-4 automatic sizing also failed (30,621,612-byte shortfall). The audit refuses initialization safely. Fixed 64-block configurations pass the lifecycle and performance paths. No runtime changes were made during this evaluation.

The new persistent speculative buffers occupy 24,310,112 bytes in the matched constructor probe. Code inspection shows they are allocated after KV sizing; the final audit subtracts the full workspace reservation after these buffers are resident. This is a likely accounting contributor, not a separately repaired/validated root-cause claim. See `auto-kv-probe-before.json`, `auto-kv-probe-after.json`, and failed automatic-KV logs.

Correctness evidence: strict graph compiler/cache/capture checks passed for 261 cycles and 80 sweep cells; graph-fast, eager-fast, and eager-invariant matched ordinary controls; lifecycle cancellation, abandonment, rollback/retry, causality and scratch-memory checks passed in fixed-KV runs. The one-ULP regression reproduced the pre-review trusted path incorrectly accepting one proposal while the repaired path and validated reference reject it. That dirty pre-review snapshot is distinct from the pre-optimization performance baseline. Adaptive GPU routing checks passed with explicitly synthetic calibration fixtures; they are not adaptive performance evidence. The previous full Qwen3-4B invariant numerical matrix is linked in `plan.json`.

Measured improvement over the pre-fix speculative implementation: **1.41–2.77× throughput in all 20 active B1/B4 cells**, with each descriptive 95% interval above 1. B8 bypass ratios remain approximately 1. Ordinary decoding with speculation disabled changed by +0.06% / +0.20% / +0.35% latency at B1/B4/B8, inside the predeclared ±5% band. All before/after greedy and ordinary-control token comparisons match.

Against the repaired ordinary decoder, the earlier five-pair run found eight of 30 cells faster with speculation (1.17–1.28×), while greedy speculation remained 1.42–1.62× slower. Faster than the old speculative implementation does not imply faster than ordinary decoding for every workload.

This expanded run retained 1,110 timing samples with zero exclusions. Full pytest afterward: **1,080 passed, 1 skipped, 14 deprecation warnings in 185.54 seconds**. A passing unit/regression suite does not supersede the failing real-GPU automatic-sizing cases.

Direct before/after timing: 5 process pairs AB/BA/AB/BA/AB; 2 warmups and seeds 17/23/41 per cell. Ratios are before wall time / after wall time, so above 1 means the repair bundle is faster. Each pair contributes its median of 3 seed ratios; exact descriptive 95% bootstrap resamples the five process pairs. This does not isolate individual edits.

## Speculation enabled before and after

| Batch | Context | Sampling | Before/after ratio | 95% interval | Before ms | After ms |
| ---: | ---: | --- | ---: | --- | ---: | ---: |
| 1 | 32 | combined | 2.210 | 2.141–2.525 | 1588.8 | 711.6 |
| 1 | 32 | greedy | 1.414 | 1.383–1.438 | 1206.3 | 853.2 |
| 1 | 32 | plain | 2.446 | 2.312–2.596 | 1089.1 | 429.8 |
| 1 | 32 | topk | 2.132 | 2.005–2.509 | 1540.6 | 688.4 |
| 1 | 32 | topp | 2.452 | 2.357–2.553 | 1123.3 | 448.4 |
| 1 | 256 | combined | 2.309 | 2.268–2.497 | 1151.2 | 483.0 |
| 1 | 256 | greedy | 1.458 | 1.439–1.502 | 1122.8 | 774.2 |
| 1 | 256 | plain | 2.364 | 2.329–2.737 | 1049.8 | 432.1 |
| 1 | 256 | topk | 2.284 | 2.228–2.354 | 1069.5 | 463.6 |
| 1 | 256 | topp | 2.341 | 2.307–2.475 | 1067.5 | 457.7 |
| 4 | 32 | combined | 2.196 | 2.172–2.504 | 1838.8 | 844.1 |
| 4 | 32 | greedy | 1.416 | 1.381–1.511 | 1256.6 | 875.7 |
| 4 | 32 | plain | 2.355 | 2.323–2.714 | 1449.8 | 608.2 |
| 4 | 32 | topk | 2.567 | 2.352–2.637 | 1956.8 | 790.8 |
| 4 | 32 | topp | 2.768 | 2.576–2.905 | 1500.5 | 593.3 |
| 4 | 256 | combined | 2.380 | 2.271–2.623 | 1601.3 | 689.5 |
| 4 | 256 | greedy | 1.456 | 1.408–1.532 | 1215.9 | 837.8 |
| 4 | 256 | plain | 2.198 | 2.154–2.447 | 1117.3 | 504.7 |
| 4 | 256 | topk | 2.415 | 2.279–2.722 | 1752.7 | 696.4 |
| 4 | 256 | topp | 2.171 | 2.083–2.467 | 1188.8 | 541.0 |
| 8 | 32 | combined | 1.000 | 0.997–1.006 | 624.5 | 625.7 |
| 8 | 32 | greedy | 1.005 | 0.993–1.010 | 565.7 | 561.0 |
| 8 | 32 | plain | 1.001 | 0.993–1.021 | 575.2 | 574.5 |
| 8 | 32 | topk | 1.001 | 0.982–1.017 | 582.4 | 581.9 |
| 8 | 32 | topp | 1.000 | 0.994–1.006 | 618.8 | 619.9 |
| 8 | 256 | combined | 0.998 | 0.991–1.003 | 712.0 | 712.7 |
| 8 | 256 | greedy | 0.999 | 0.991–1.005 | 647.1 | 650.2 |
| 8 | 256 | plain | 1.000 | 0.996–1.005 | 662.4 | 663.5 |
| 8 | 256 | topk | 0.996 | 0.975–1.005 | 667.6 | 667.7 |
| 8 | 256 | topp | 0.998 | 0.988–1.000 | 705.1 | 709.1 |
## Speculation disabled regression control

| Batch | Context | Sampling | Before/after ratio | 95% interval | Before ms | After ms |
| ---: | ---: | --- | ---: | --- | ---: | ---: |
| 1 | 32 | plain | 0.999 | 0.990–1.009 | 547.4 | 548.0 |
| 4 | 32 | plain | 0.998 | 0.995–1.022 | 547.8 | 549.1 |
| 8 | 32 | plain | 0.997 | 0.993–1.014 | 556.4 | 555.1 |

Greedy/ordinary-control mismatch records: 0. Excluded timing samples: 0. Raw reports retain all selections, work counters, hashes, hardware boundary snapshots, and calibration roofs.

Full pytest after these benchmarks: {'tests': 1081, 'failures': 0, 'errors': 0, 'skipped': 1, 'passed': 1080}.

Existing repaired on/off five-pair performance results: [report](../performance-five-pair-arrival/README.md). Strict and ordinary controls, adaptive checks, automatic-sizing failures, before/after pairs, extended workloads, configured-K cap checks and JUnit results are retained here. This covers the documented single-GPU Qwen3 envelope, not all models, production traffic, TP>1, FlashInfer speculation, or an independently calibrated adaptive speedup claim. Extended/cap timings have one process per side and do not carry five-pair confidence. All timings use warmed synthetic prompts; prefix-cache hits are possible.
