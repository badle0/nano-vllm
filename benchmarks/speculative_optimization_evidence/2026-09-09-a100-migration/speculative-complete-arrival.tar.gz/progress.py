import json,pathlib
p=pathlib.Path(__file__).resolve().parent
if (p/'benchmark-status.json').exists():
 s=json.loads((p/'benchmark-status.json').read_text());rs=s.get('runs',[])
 print('completed:',len(rs),'failed:',[r['name'] for r in rs if r['exit_code']],'samples:',sum(r.get('samples',0) for r in rs),'accepted:',sum(r.get('accepted',0) for r in rs))
if (p/'benchmark-runner.log').exists():
 lines=(p/'benchmark-runner.log').read_text().splitlines();print('\n'.join(lines[-2:]))
 starts=[x for x in lines if x.startswith('START ')]
 if starts:
  log=p/(starts[-1].split()[1]+'.log')
  if log.exists():print(log.read_text()[-450:])
