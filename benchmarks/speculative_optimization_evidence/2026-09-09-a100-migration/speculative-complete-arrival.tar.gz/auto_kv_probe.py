"""Instrument constructor accounting without altering its sizing or audit decisions."""
import argparse,dataclasses,json,pathlib,sys
parser=argparse.ArgumentParser();parser.add_argument('--source-root',type=pathlib.Path,required=True);parser.add_argument('--output',type=pathlib.Path,required=True);args=parser.parse_args()
sys.path.insert(0,str(args.source_root.resolve()))
import torch
from nanovllm import LLM
from nanovllm.engine.model_runner import ModelRunner
original=ModelRunner._finalize_speculative_memory_audit
record={'source_root':str(args.source_root.resolve()),'max_batch':5,'memory_utilization':.5}
def observe(self):
 record['sizing_inputs']=self._speculative_memory_audit_inputs
 storages={}
 for name in ('_spec_q_rows','_spec_proposal_ids','_spec_target_probability_rows','_spec_bonus_noise','_spec_result_rows'):
  t=getattr(self,name,None)
  if isinstance(t,torch.Tensor):storages[t.untyped_storage().data_ptr()]=t.untyped_storage().nbytes()
 record['resident_speculative_workspace_bytes']=sum(storages.values())
 try:result=original(self)
 except Exception as e:
  record['exception']=f'{type(e).__name__}: {e}';raise
 record['audit']=dataclasses.asdict(self.speculative_memory_audit) if dataclasses.is_dataclass(self.speculative_memory_audit) else self.speculative_memory_audit._asdict()
 return result
ModelRunner._finalize_speculative_memory_audit=observe
llm=None
try:
 llm=LLM('/workspace/models/Qwen3-4B',draft_model='/workspace/models/Qwen3-0.6B',num_speculative_tokens=4,max_num_seqs=5,max_num_batched_tokens=1024,max_model_len=512,gpu_memory_utilization=.5,enforce_eager=False)
 record['initialized']=True
except Exception as e:
 record['initialized']=False;record['exception']=f'{type(e).__name__}: {e}'
finally:
 if llm is not None:llm.exit()
 ModelRunner._finalize_speculative_memory_audit=original
 with args.output.open('x') as f:json.dump(record,f,indent=2,default=str)
print(json.dumps({k:v for k,v in record.items() if k not in ('sizing_inputs','audit')},indent=2),flush=True)
raise SystemExit(0 if record['initialized'] else 1)
