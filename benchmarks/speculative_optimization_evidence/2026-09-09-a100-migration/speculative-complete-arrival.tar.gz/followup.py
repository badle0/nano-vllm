import json,os,pathlib,subprocess
root=pathlib.Path(__file__).resolve().parent;repo=pathlib.Path('/workspace/nano-vllm');python='/workspace/venvs/nano-vllm/bin/python'
env=os.environ.copy();env.update(PYTHONDONTWRITEBYTECODE='1',PYTHONPATH=str(repo),HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',CUDA_VISIBLE_DEVICES='0')
tasks=[('graph-auto-kv-b4',[python,'tests/run_speculative_v5_gpu.py','--model','/workspace/models/Qwen3-4B','--draft-model','/workspace/models/Qwen3-0.6B','--mode','graph','--enabled','--sweep','--auto-kv','--output',str(root/'graph-auto-kv-b4.json')]),('adaptive-gpu',[python,str(root/'adaptive_gpu.py')])]
status=[]
for name,cmd in tasks:
 print('START',name,flush=True)
 e=env.copy();e.update(TORCHINDUCTOR_CACHE_DIR=str(root/(name+'-inductor-cache')),TRITON_CACHE_DIR=str(root/(name+'-triton-cache')))
 with (root/(name+'.log')).open('x') as f:rc=subprocess.run(cmd,cwd=repo,env=e,stdout=f,stderr=subprocess.STDOUT).returncode
 status.append({'name':name,'exit_code':rc});(root/'followup-status.json').write_text(json.dumps(status,indent=2)+'\n');print('FINISH',name,rc,flush=True)
print('START BENCHMARKS',flush=True)
with (root/'benchmark-runner.log').open('x') as f:rc=subprocess.run([python,'-u',str(root/'benchmark.py')],cwd=repo,env=env,stdout=f,stderr=subprocess.STDOUT).returncode
print('BENCHMARK RUNNER FINISHED',rc,flush=True)
raise SystemExit(rc)
