import datetime,json,os,pathlib,subprocess
root=pathlib.Path(__file__).resolve().parent;repo=pathlib.Path('/workspace/nano-vllm');python='/workspace/venvs/nano-vllm/bin/python'
plan=json.loads((root/'plan.json').read_text())
env=os.environ.copy();env.update(PYTHONDONTWRITEBYTECODE='1',PYTHONPATH=str(repo),HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',CUDA_VISIBLE_DEVICES='0',NANOVLLM_TEST_TOKENIZER_PATH='/workspace/models/Qwen3-0.6B')
status={'runs':[]}
def save(): (root/'benchmark-status.json').write_text(json.dumps(status,indent=2)+'\n')
def run(name,cmd):
 print('START',name,datetime.datetime.now(datetime.timezone.utc).isoformat(),flush=True)
 e=env.copy();e.update(TORCHINDUCTOR_CACHE_DIR=str(root/(name+'-inductor-cache')),TRITON_CACHE_DIR=str(root/(name+'-triton-cache')))
 with (root/(name+'.log')).open('x') as f:rc=subprocess.run(cmd,cwd=repo,env=e,stdout=f,stderr=subprocess.STDOUT).returncode
 r={'name':name,'exit_code':rc}
 output=root/(name+'.json')
 if rc==0 and output.exists():
  d=json.loads(output.read_text());r.update(samples=len(d.get('records',[])),accepted=sum(x['accepted'] for x in d.get('records',[])))
 status['runs'].append(r);save();print('FINISH',json.dumps(r),flush=True)
 return rc
def command(name,revision,source,suite,enabled,pair=0,k=4):
 cmd=[python,'tests/run_speculative_v7_benchmark.py','--model','/workspace/models/Qwen3-4B','--draft-model','/workspace/models/Qwen3-0.6B','--revision',revision,'--source-root',str(source),'--mode','graph','--suite',suite,'--pair',str(pair),'--configured-k',str(k),'--output',str(root/(name+'.json'))]
 if enabled:cmd.append('--enabled')
 return cmd
def counts(prefix):
 counts={}
 for pair in range(6):
  paths=[root/f'{prefix}-p{pair}-{s}.json' for s in ('before','after')]
  if not all(p.exists() for p in paths):continue
  ds=[json.loads(p.read_text()) for p in paths]
  def key(r):return tuple(r[k] for k in ('batch','context','family','consumer','completion'))
  for cell in {key(r) for r in ds[0]['records']}:
   groups=[[r for r in d['records'] if key(r)==cell] for d in ds]
   if all(len(g)==3 and {r['seed'] for r in g}=={17,23,41} and all(r['accepted'] for r in g) for g in groups):counts[cell]=counts.get(cell,0)+1
 return counts
for side in ('before','after'):
 name='auto-kv-probe-'+side
 source=root/'baseline' if side=='before' else repo
 run(name,[python,str(root/'auto_kv_probe.py'),'--source-root',str(source),'--output',str(root/(name+'.json'))])
for prefix,suite,enabled,ncells in [('active','primary',True,30),('off','off-regression',False,3)]:
 for pair in range(6):
  if pair==5:
   c=counts(prefix)
   if len(c)==ncells and min(c.values())>=5:break
  for side in (('before','after') if pair%2==0 else ('after','before')):
   name=f'{prefix}-p{pair}-{side}'
   revision=plan[side+'_revision'];source=root/'baseline' if side=='before' else repo
   run(name,command(name,revision,source,suite,enabled,pair))
 c=counts(prefix);status[prefix+'_five_pair_gate']=len(c)==ncells and min(c.values())>=5;save()
for side in ('off','on'):
 name='extended-'+side;run(name,command(name,plan['after_revision'],repo,'extended',side=='on'))
for k in (5,6):
 name=f'configured-k{k}';run(name,command(name,plan['after_revision'],repo,'smoke',True,k=k))
run('pytest',[python,'-m','pytest','-q','-p','no:cacheprovider','--junitxml='+str(root/'pytest.xml')])
print('ALL BENCHMARKS AND PYTEST COMPLETE',flush=True)
