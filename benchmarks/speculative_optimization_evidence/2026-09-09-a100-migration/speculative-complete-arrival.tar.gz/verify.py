import datetime,hashlib,json,os,pathlib,subprocess
root=pathlib.Path(__file__).resolve().parent
repo=pathlib.Path('/workspace/nano-vllm');python='/workspace/venvs/nano-vllm/bin/python'
revision=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
before=subprocess.check_output(['git','rev-parse','198e1e6'],cwd=repo,text=True).strip()
env=os.environ.copy();env.update(PYTHONDONTWRITEBYTECODE='1',PYTHONPATH=str(repo),HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',CUDA_VISIBLE_DEVICES='0',NANOVLLM_TEST_TOKENIZER_PATH='/workspace/models/Qwen3-0.6B')
flags=['TORCHINDUCTOR_FX_GRAPH_REMOTE_CACHE','TORCHINDUCTOR_AUTOGRAD_CACHE','TORCHINDUCTOR_AUTOGRAD_REMOTE_CACHE','TORCHINDUCTOR_AUTOTUNE_REMOTE_CACHE','TORCHINDUCTOR_BUNDLED_AUTOTUNE_REMOTE_CACHE','TORCH_DYNAMO_AUTOMATIC_DYNAMIC_LOCAL_PGO','TORCH_DYNAMO_AUTOMATIC_DYNAMIC_REMOTE_PGO']
env.update({k:'0' for k in flags});env['TORCH_LOGS']='recompiles,graph_breaks'
for k in ['TORCH_COMPILE_DISABLE','TORCHDYNAMO_DISABLE','TORCHDYNAMO_SUPPRESS_ERRORS']:env.pop(k,None)
plan={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'before_revision':before,'after_revision':revision,'purpose':'Full bounded Qwen3-4B target / Qwen3-0.6B speculative verification plus direct measurement of the repair/optimization bundle','verification':['strict retained graph-fast off/on at max batch 5, on sweep B1..4 K1..4 plus B5 bypass','eager-fast off/on with same lifecycle fixtures','eager-invariant ordinary control matched to previous speculative sweep','graph-fast automatic-KV lifecycle sweep','extended current off/on workload matrix','configured K5 and K6 cap checks'],'before_after':'Five fresh paired processes before-on/after-on over all 30 primary cells, AB/BA/AB/BA/AB. Then five before-off/after-off pairs over the three off-regression cells.','pair_policy':'Use first five complete accepted pairs per cell; append at most one full BA repair pair if exclusions/failures leave a cell short. Preserve failures and excluded samples, never select by latency.','statistics':'Pair median of three same-seed before/after wall-time ratios; exact 95% descriptive bootstrap across five process pairs; +/-5% off-regression band.','existing_evidence':['/workspace/verification/qwen4-first-qualification','/workspace/verification/speculative-target-draft-arrival','/workspace/verification/performance-five-pair-arrival'],'limits':'One A100, BF16 Qwen3 pair, TP1 exact sampling. No claim of all models/production traces; adaptive routing calibration not benchmarked by fixed-K protocol.'}
(root/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
(root/'environment-vars.json').write_text(json.dumps({k:v for k,v in env.items() if k.startswith(('TORCH','TRITON'))},indent=2)+'\n')
checks=[('graph-fast-off',['--mode','graph','--max-batch','5','--retained','--expected-commit',revision]),('graph-fast-on',['--mode','graph','--max-batch','5','--enabled','--sweep','--retained','--expected-commit',revision]),('eager-fast-off',['--mode','eager','--max-batch','5']),('eager-fast-on',['--mode','eager','--max-batch','5','--enabled','--sweep']),('eager-invariant-off',['--mode','eager','--numerical-mode','invariant']),('graph-auto-kv-on',['--mode','graph','--max-batch','5','--enabled','--sweep','--auto-kv'])]
status=[]
for name,args in checks:
 print('START',name,datetime.datetime.now(datetime.timezone.utc).isoformat(),flush=True)
 e=env.copy();e.update(TORCHINDUCTOR_CACHE_DIR=str(root/(name+'-inductor-cache')),TRITON_CACHE_DIR=str(root/(name+'-triton-cache')))
 cmd=[python,'tests/run_speculative_v5_gpu.py','--model','/workspace/models/Qwen3-4B','--draft-model','/workspace/models/Qwen3-0.6B',*args,'--output',str(root/(name+'.json'))]
 with (root/(name+'.log')).open('x') as f:rc=subprocess.run(cmd,cwd=repo,env=e,stdout=f,stderr=subprocess.STDOUT).returncode
 status.append({'name':name,'exit_code':rc});(root/'verification-status.json').write_text(json.dumps(status,indent=2)+'\n');print('FINISH',name,rc,flush=True)
 if rc:raise SystemExit(rc)
print('VERIFICATION COMPLETE',flush=True)
