# Qwen3-4B numerical qualification — 2026-09-09

PASS: all five forced-history comparisons matched bit for bit: 55 live-KV states and 55 emission-logit states, with no mismatches. Independent FP64 primitive checks passed. The qualification command exited successfully (0); all 12 JSON report checksums were verified.

Source commit: `74eac2f9512e737d7eb1f6a1d2c97eebb5efc9ee`.
Runtime SHA-256: `fe0431d97f7f1f0ea1c1063c5339d6dabd174e332d93586cda18ddc553c4f266`.
Model: Qwen3-4B revision `1cfa9a7208912126459214e8b04321603b3df60c`; pinned checkpoint verification passed before execution (398 tensors).
Model aggregate fingerprint: `9e4ce5713af7be493c9cba5afd8c997452af8b0b6f972f74e5967159f0526a4c` (includes local paths/cache metadata).
Environment: NVIDIA A100-SXM4-40GB, driver 570.133.20, Python 3.12.13, Torch 2.10.0+cu128. Pinned environment and native FlashAttention smoke passed.

| Scenario | KV comparisons | Logit comparisons | Result |
| --- | ---: | ---: | --- |
| known_failures | 34 | 34 | Pass |
| mixed_boundaries | 14 | 14 | Pass |
| cache_reuse | 2 | 2 | Pass |
| eviction_resume | 2 | 2 | Pass |
| long_context | 3 | 3 | Pass |

Cache reuse exercised 512 cached prefix tokens. Eviction/resumption exercised one injected eviction. Long-context comparisons covered 1024, 2048, and 4096 tokens. Reference and candidate used independent engines and forced token histories.

FP64 maximum peak-relative errors:
- linear: 0.0023493916
- rmsnorm: 0.0024395927
- attention: 0.0021509621

Scope: BF16, TP=1, eager invariant numerical mode on the recorded A100. FP64 checks cover primitives, not an end-to-end FP64 model. This does not qualify fast graph/eager equivalence, speculative lifecycle behavior, performance, other hardware, or contexts beyond 4096. Full pytest and speculative/performance qualification were not run as part of this numerical matrix.

Reproduction (requires a new output directory):

```bash
source /workspace/venvs/nano-vllm/bin/activate
cd /workspace/nano-vllm
bash deployment/a100-2026-09-09/qualify_numerics.sh /workspace/models/Qwen3-4B /workspace/verification/qwen4-repeat
```

Raw reports and their original SHA256SUMS are in this directory. Execution log: `/workspace/verification/qwen4-first-qualification.log`. Repository source was unchanged.
